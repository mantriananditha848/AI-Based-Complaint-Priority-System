"""
URL configuration for civic_complaint_system project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from user_portal.urls import template_urlpatterns

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # API endpoints
    path('api/user/', include('user_portal.urls')),
    
    # Admin Portal (staff-only)
    path('admin-portal/', include('admin_portal.urls')),
    
    # Contractor Portal (contractor users)
    path('contractor/', include('contractor_portal.urls')),
    
    # Template pages
    path('', include(template_urlpatterns)),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
